﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    public static int count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox textbox1 = new TextBox();
        Label3.Visible = false;
    }
   /* protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        if (Login1.UserName == "admin" && Login1.Password == "admin")
        {
            Response.Redirect("admin.aspx");
        }
        if(Membership.ValidateUser(Login1.UserName,Login1.Password))
        {
            if (User.IsInRole("Teacher"))
            {
                Response.Redirect("teachermain.aspx");
            }
            else
            {
                Response.Redirect("Teacherlogin.aspx");
                count = 1;

            }
            Response.Redirect("home.aspx");
        }
     
    }
    */
    protected void LoginButton_Click(object sender, EventArgs e)
    {

        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();
        d = new SqlDataAdapter("select * from usr where username=" + TextBox1.Text + "", con);
         string a = t.Rows[0]["password"].ToString();
         TextBox2.Text = a;

        /*  for(int i=0;i<t.Rows.Count;i++)
          {
              if (Login1.UserName == t.Rows[i]["username"].ToString())
              {
                 Response.Redirect("index.aspx");
                  if (Login1.Password == t.Rows[i]["password"].ToString())
                  {
                                      }
              }
              else
                  Response.Redirect("home.aspx");
          }*/

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != "")
        {
            string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();
            d = new SqlDataAdapter("select * from usr", con);
            d.Fill(t);
            //   Label3.Text = t.Rows[0]["password"].ToString();
            //TextBox2.Text = a;
            for (int i = 0; i < t.Rows.Count; i++)
            {
                if (TextBox1.Text.Trim() == t.Rows[i]["username"].ToString().Trim())
                {
                    //Response.Redirect("index.aspx");
                    if (TextBox2.Text.Trim() == t.Rows[i]["password"].ToString().Trim())
                    {
                        if (t.Rows[i]["type"].ToString().Trim() == "Student")
                        {
                            Session.RemoveAll();
                            Session["student"] = t.Rows[i]["name"].ToString();
                            Response.Redirect("student.aspx");
                        }
                        else if (t.Rows[i]["type"].ToString().Trim() == "Teacher")
                        {
                            Session["teacher"] = t.Rows[i]["name"].ToString();
                            Response.Redirect("teacher.aspx");
                        }
                    }
                    else
                    {
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        TextBox1.Focus();
                        Label3.Visible = true;
                        Label3.Text = "Incorrect Id Or Password";
                    }
                }
            }

        }
        else {
            Label3.Visible = true;
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox1.Focus();
            Label3.Text = "please enter user name and password first";
        
        
        }
    }

}