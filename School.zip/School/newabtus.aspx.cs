﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class newabtus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {if (Session["admin"] != null)
                 {
                     //Button2.Visible = true;
                     Label1.Visible = false;
                    // Label2.Visible = false;
                 }
                 else if (Session["student"] != null)
                 {
                     //Button2.Visible = true;
                     Label1.Visible = false;
                 }
                 else if (Session["teacher"] != null)
                 {
                     //Button2.Visible = true;
                     Label1.Visible = false;
                 }


    }
}