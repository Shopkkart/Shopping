﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing.Drawing2D;
using System.Data.SqlClient;
using System.Data;


public partial class Default4 : System.Web.UI.Page
{
    public static int c = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin"] != null)
        {
            FileUpload1.Visible = true;
            Button1.Visible = true;
        }
        else
        {
            FileUpload1.Visible = false;
            Button1.Visible = false;

            foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/Data/")))
            {

                ImageButton imagebutton = new ImageButton();
                FileInfo fileinfo = new FileInfo(strfilename);
                imagebutton.ImageUrl = "~/Data/" + fileinfo.Name;
                imagebutton.Width = Unit.Pixel(300);
                imagebutton.Height = Unit.Pixel(300);
                imagebutton.Style.Add("padding", "5px");
                //imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
                // imagebutton.OnClientClick += new imag



                Panel1.Controls.Add(imagebutton);

            }

        }
        
    }      
        
    protected void  Button1_Click1(object sender, EventArgs e)
{
 if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName;
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Data/" + filename));


        }
        foreach (string strfilename in Directory.GetFiles(Server.MapPath("~/Data/")))
        {

            ImageButton imagebutton = new ImageButton();
            FileInfo fileinfo = new FileInfo(strfilename);
            imagebutton.ImageUrl = "~/Data/" + fileinfo.Name;
            imagebutton.Width = Unit.Pixel(300);
            imagebutton.Height = Unit.Pixel(300);
            imagebutton.Style.Add("padding", "5px");
            //imagebutton.Click += new ImageClickEventHandler(imagebutton_Click);
           // imagebutton.OnClientClick += new imag
            
        

            Panel1.Controls.Add(imagebutton);
        }
}

    void imagebutton_Click(object sender, ImageClickEventArgs e)
    {  //  string jsMethodName= = "NewPage()";
        //ScriptManager.RegisterClientScriptBlock(this, typeof(string), "uniqueKey", jsMethodName, true);
        //throw new NotImplementedException();
        Response.Redirect("index.aspx");
    }
    public static string a;
 

}