﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing.Drawing2D;

public partial class att : System.Web.UI.Page
{
    string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
    public static string[] a = new string[100];
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();

        d = new SqlDataAdapter("select name from studentdetail where class in (select class from studentdetail where branch='information_Technology')" + "", con);

        d.Fill(t);



        DropDownList1.Visible = false;
        DropDownList2.Visible = false;
        Button1.Visible = false;
        // int a = int.Parse(Text1.Text);
        Table tb = new Table();
        //tb.ID = "myTable";

        tb.Attributes["class"] = "table table-striped";
        for (int i = 0; i <= t.Rows.Count - 1; i++)
        {
            TableRow tr = new TableRow();
            //   tr.ID = "row" + i.ToString();
            for (int j = 0; j < 2; j++)
            {
                TableCell tc = new TableCell();
                //   tc.ID = "cell" + i.ToString() + j.ToString();
                //    tc.Text = "";
                //tc.Height = 25;
                // for (i = 1; i <= t.Rows.Count && j == 1; i++)
                //{
                //TextBox tx = new TextBox();
                if (i < t.Rows.Count && j == 0)
                {

                    TextBox l = new TextBox();

                    l.Text = t.Rows[i]["name"].ToString();
                    // cb.ID = "TextBoxRow_" + i + "Col_" + j;
                   tc.Controls.Add(l);
                   // Panel1.Controls.Add(l);
                    tc.BackColor = System.Drawing.ColorTranslator.FromHtml("#F2F0E1");

                }
                if (j == 1)
                {
                    CheckBox cb = new CheckBox();
                    cb.Checked = false;
                    
                    // cb.ID = "TextBoxRow_" + i + "Col_" + j;
                    tc.BackColor = System.Drawing.ColorTranslator.FromHtml("#F2F0E1");
                   // tc.Controls.Add(cb);
                    Panel1.Controls.Add(cb);

                }
                /*else
                {
                    if (i <= t.Rows.Count)
                    {                         // Button1.Text = "lok";
                        TextBox l = new TextBox();
                        //l.Text = "dsfdsfdsf";
                        l.Text = t.Rows[i]["name"].ToString();
                        // cb.ID = "TextBoxRow_" + i + "Col_" + j;
                        tc.Controls.Add(l);
                        tc.BackColor = System.Drawing.ColorTranslator.FromHtml("#F2F0E1");

                    }
                }*/
                tr.Controls.Add(tc);
                //  j = 0;
            }

            /*
              
                            if (i == 0 && j == 0)
                            {
                                tc.Text = "Roll NO.";
                            }
                            else if (i == 0 && j == 1)
                            {
                                tc.Text = "Name";
                            }
                            if (j == 0 && i != 0)
                            {

                                tc.Text = i.ToString();
                            }
                            if (j != 1 && i != 0)
                            {
                                tc.Width = 40;

                            }
                            else
                            {
                                tc.Width = 80;
                            }

                        }
                        tb.CellPadding = 2;
                        tb.Attributes["class"] = "table table-striped";
                        tb.Rows.Add(tr);
                    }*/
            Form.Controls.Add(tb);

            Button b = new Button();
            b.Text = "submit";
            b.ID = "btn";
            b.Click += new EventHandler(b_Click);
            Form.Controls.Add(b);

            tb.Rows.Add(tr);
        }
    }

    void b_Click(object sender, EventArgs e)
    {
       
        foreach (CheckBox cd in Panel1.Controls.OfType<CheckBox>())
        {
            int i=0;
            if (cd.Checked == true)
            {
                i++;
                a[i] = "true";

            }
            else
            {
                i++;
                a[i] = "false";
            }

            string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lokesh\Desktop\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();

            d = new SqlDataAdapter("insert into usr values(@)", con);
        }

        /*      foreach (TextBox textBox in Panel1.Controls.OfType<TextBox>())
             {
                 foreach (CheckBox cd in Panel1.Controls.OfType<CheckBox>())
                 {
                     string constr = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
                     using (SqlConnection c = new SqlConnection(con))
                     {
                         using (SqlCommand cmd = new SqlCommand("INSERT INTO atndnc VALUES(@Name,@atndnc)"))
                         {
                             cmd.Connection = c;
                             cmd.Parameters.AddWithValue("@Name", textBox.Text);
                             cmd.Parameters.AddWithValue("@atndnc", cd.ToString());

                             c.Open();
                             cmd.ExecuteNonQuery();
                             c.Close();
                         }
                     }
                 }
             }
             Response.Write("hiiii");
         }*/
    }
}



    