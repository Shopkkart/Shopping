﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class tprofile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Lokesh\Desktop\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
        SqlDataAdapter d = new SqlDataAdapter();
        DataTable t = new DataTable();

        d = new SqlDataAdapter("insert into result values(@a,@b,@c,@d,@e,@f,@g,@h,@i)", con);

        d.SelectCommand.Parameters.AddWithValue("a", TextBox1.Text);
        d.SelectCommand.Parameters.AddWithValue("b", TextBox2.Text);
        d.SelectCommand.Parameters.AddWithValue("c", TextBox3.Text);
        d.SelectCommand.Parameters.AddWithValue("d", TextBox4.Text);
        d.SelectCommand.Parameters.AddWithValue("e", TextBox5.Text);
        d.SelectCommand.Parameters.AddWithValue("f", TextBox6.Text);
        d.SelectCommand.Parameters.AddWithValue("g", TextBox7.Text);
        d.SelectCommand.Parameters.AddWithValue("h", TextBox8.Text);
        d.SelectCommand.Parameters.AddWithValue("i", TextBox9.Text); 
        d.Fill(t);

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
}