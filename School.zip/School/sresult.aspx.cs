﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class sresult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["student"] != null)
        {
            string con = @"Data Source=.\SQLEXPRESS;AttachDbFilename=G:\School\App_Data\ASPNETDB.MDF;Integrated Security=True;User Instance=True";
            SqlDataAdapter d = new SqlDataAdapter();
            DataTable t = new DataTable();
            string a = Session["student"].ToString().Trim();
            //  d = new SqlDataAdapter("select * from result where name="+Session["student"].ToString().Trim(), con);
            d = new SqlDataAdapter("select * from result where name='Lokesh'", con);
            d.Fill(t);
                if (t.Rows[0]["name"].ToString().Trim() == Session["student"].ToString().Trim())
                {

                    TextBox1.Text = "Hindi";
                    TextBox3.Text = "English";
                    TextBox5.Text = "Maths";
                    TextBox7.Text = "Biology";
                    TextBox9.Text = "chemistry";
                    TextBox11.Text = "physics";

                    TextBox2.Text = t.Rows[0]["sub1"].ToString();
                    TextBox4.Text = t.Rows[0]["sub2"].ToString();
                    TextBox6.Text = t.Rows[0]["sub3"].ToString();
                    TextBox8.Text = t.Rows[0]["sub4"].ToString();
                    TextBox10.Text = t.Rows[0]["sub5"].ToString();
                    TextBox12.Text = t.Rows[0]["sub6"].ToString();

                    int a1 = int.Parse(TextBox2.Text);
                    int a2 = int.Parse(TextBox4.Text);
                    int a3 = int.Parse(TextBox6.Text);
                    int a4 = int.Parse(TextBox8.Text);
                    int a5 = int.Parse(TextBox10.Text);
                    int a6 = int.Parse(TextBox12.Text);
                    int total = a1 + a2 + a3 + a4 + a5 + a6;
                    TextBox14.Text = total.ToString();
                    TextBox15.Text = (total / 6).ToString();
                    //TextBox1.Text = Session["student"].ToString(); 
                }

                else
                { Response.Write("Error"); }
            }
        }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.RemoveAll();
        Response.Redirect("index.aspx");
    }
}
